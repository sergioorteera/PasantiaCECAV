<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Oferta_personal extends Model
{
    use HasFactory;
    protected $table = 'oferta_personal';
}
