<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Oferta;
use App\Models\Categoria;
use App\Models\User;

class InscripcionOfertaController extends Controller
{
    
}